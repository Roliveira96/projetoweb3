<?php

$banco = [
    'driver' => 'mysql',
    'servidor' => 'localhost',
    'porta' => '3306',
    'banco' => 'projeto',
    'usuario' => 'ricardo',
    'senha' => 'ricardo123',
];
