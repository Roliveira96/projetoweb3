<h1 class="hide">cod_1992</h1>



<div class="row">
    <h4 class="center">Sala de Espera</h4>




                    <div class="row">
                        <div class="col s12 m3">
                            <div class="card blue-grey darken-1">
                                <div class="card-content white-text">
                                    <span class="card-title">Sala Teste </span>
                                    <p>Sala teste </p>
                                </div>
                                <div class="card-action">
                                    <a href="<?= URL_RAIZ . 'partida'?>">1° Jogador</a>
                                    <a href="#">2° Jogador</a>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>





