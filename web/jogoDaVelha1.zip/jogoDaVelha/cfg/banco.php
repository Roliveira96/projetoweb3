<?php

$banco = [
    'driver' => 'mysql',
    'servidor' => 'localhost',
    'porta' => '3306',
    'banco' => 'jogo',
    'usuario' => 'ricardo',
    'senha' => 'ricardo123',
];
