<?php
namespace Controlador;

use \Framework\DW3Controlador;

abstract class Controlador extends DW3Controlador

{

}
