
<h1> Partida</h1>

                                    <table class="striped" border="1">

                                        <tr class="row">
                                            <td id="1"></td>
                                            <td id="2"></td>
                                            <td id="3"></td>
                                        </tr>

                                        <tr class="row">
                                            <td id="4"></td>
                                            <td id="5"></td>
                                            <td id="6"></td>
                                        </tr>

                                        <tr class="row">
                                            <td id="7"></td>
                                            <td id="8"></td>
                                            <td id="9"></td>
                                        </tr>

                                    </table>




