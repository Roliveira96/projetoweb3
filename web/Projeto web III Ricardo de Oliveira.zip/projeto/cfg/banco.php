<?php

$banco = [
    'driver' => 'mysql',
    'servidor' => 'localhost',
    'porta' => '3306',
    'banco' => 'sistema_de_perguntas',
    'usuario' => 'ricardo',
    'senha' => 'ricardo123',
];
