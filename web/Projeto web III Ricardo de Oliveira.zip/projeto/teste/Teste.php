<?php
namespace Teste;

use \Framework\DW3Teste;

abstract class Teste extends DW3Teste
{

}

