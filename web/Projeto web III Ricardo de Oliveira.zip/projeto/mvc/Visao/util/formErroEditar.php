<?php
if(isset($erro[$campo]))
  echo '  <div class="center animated shake delay-1s">
        <span class="red-text"> ' .$erro[$campo] .' </span>

    </div>';
