<h1 class="hide">home</h1>
<a class="sp-circle-link" href="<?= URL_RAIZ .'login' ?>">PLAY</a>

    <div class="sp-container">
        <div class="sp-content">
            <section class="fullsize-video-bg">
                <div id="video-viewport">
                    <video width="1920" height="1280" autoplay muted loop>
                        <source src="https://static.videezy.com/system/resources/previews/000/036/901/original/hand-touch12.mp4" type="video/mp4" />
                        <source src="https://storage.googleapis.com/coverr-main/webm/Winter-Grass.webm" type="video/webm" />
                    </video>
                </div>
            </section>
            <div class="sp-globe"></div>
            <h2 class="frame-1">Seja veloz!</h2>

            <h2 class="frame-2">Supere seus limites</h2>

            <h2 class="frame-3">Seja forte!</h2>

            <h2 class="frame-4">Seja ágil!</h2>

            <h2 class="frame-5"><span>Resolva,</span> <span>crie,</span> <span>desafia seus oponentes</span>


            </h2>


        </div>
    </div>

